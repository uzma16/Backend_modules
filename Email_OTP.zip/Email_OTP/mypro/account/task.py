# from django.core.mail import send_mail
from django.contrib.auth import get_user_model
import random
from mypro import settings
from django.core.mail import send_mail


def send_otp(self):
    users=get_user_model().objects.all()
    for user in users:
       mail_sub='Mail for verification'
       message='Hii you got the mail'
       to_mail=user.mail
       send_mail(
                subject=mail_sub,
                message=message,
                from_email=settings.EMAIL_HOST_USER,
                recipient_list=[to_mail],
                fail_silently=True,
                )
    return "Done"

