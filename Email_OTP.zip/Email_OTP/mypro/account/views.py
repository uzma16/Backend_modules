from django.shortcuts import render,HttpResponse


# Create your views here.
from .task import send_otp
import time

def otp(request):
    send_otp
    return HttpResponse("Done")