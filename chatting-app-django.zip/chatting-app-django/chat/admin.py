from django.contrib import admin
from chat.models import Message

# Register your models here.
admin.site.register(Message)
