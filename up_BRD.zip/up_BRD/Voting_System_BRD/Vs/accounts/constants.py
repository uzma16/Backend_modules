GENDER_CHOICES = {
        ('Male', 'Male'),
        ('Female', 'Female')
    }